﻿var CountryVar, SiteVar, SubjectVar, StatusVar, FiterAdvObj1, filterApplied;
var SelectedDataClass = [];
var selectedInputFieldsDone = [];
var CountrisList = [], SiteList = [], SubjectList = [], StatusList = [];
var AdvanceFilterApplied = false;
$('#AdvFilterModal').modal({ backdrop: 'static', keyboard: false })
$(document).on('click', function (event) {
    var modal = $('#AdvFilterModal');
    if (modal.is(':visible') && !modal.is(event.target) && !modal.has(event.target).length) {
        $("#AdvFilterModal .modal-close").trigger('click');
    }
})
$(document).ready(function () {
    $(document).on('click', function (event) {
        console.log('event.target', event.target);
        if ($(event.target).attr('class') != null) {
            var data = (($(event.target).attr('class')).split(' '));
            if (data[1] != 'AdvCheckBoxCls') {
                if (($(event.target.nextSibling).attr('class')) != null) {
                    var name = (($(event.target.nextSibling).attr('class')).split(' '));
                    if (name[1] == 'DrpContain') {
                        if (name[2] == 'show') {
                            $('.' + name[0]).addClass("show");
                        }
                        else {
                            $(".DrpContain").removeClass("show");
                        }
                    }
                }
                else {

                    $(".DrpContain").removeClass("show");
                }
            }
        }
    });
})
/* ShowFilterOptions used For Adding dynamic Data to filter options  */
function ShowFilterOptions(MetricName, ...MetricData) {
    CountrisList = [], SiteList = [], SubjectList = [], StatusList = [];
    /*Add generic filter layout */
    AddGenericfilter()

    if (MetricData && MetricData.length > 0) {
        /** CreateCountryAdvanceFilter,CreateSiteAdvanceFilterCreateSubjectAdvanceFilter for Common Filters Design*/
        MetricData.forEach(function (DtElement, i) {
            if (DtElement && DtElement[0]) {
                if (i == MetricData.length - 1) {
                    CreateCountryAdvanceFilter(DtElement, 1)
                    CreateSiteAdvanceFilter(DtElement, 1)
                    CreateSubjectAdvanceFilter(MetricName, DtElement, 1)
                    CreateStatusAdvanceFilter(DtElement, 1)
                }
                else {
                    CreateCountryAdvanceFilter(DtElement, 0)
                    CreateSiteAdvanceFilter(DtElement, 0)
                    CreateSubjectAdvanceFilter(DtElement, 0)
                    CreateStatusAdvanceFilter(DtElement, 0)
                }
            }
        })
        $("#AdvFilterModal #PageLevelFiltersId").empty();
        /** CreatePageLevelFilters for Page level Filters Design */
        CreatePageLevelFilters(MetricName, MetricData)
    }
    filterCountry = CheckNull(JSON.parse(sessionStorage.getItem("filterCountry")));
    filterSite = CheckNull(JSON.parse(sessionStorage.getItem("filterSite")));
    filterSubject = CheckNull(JSON.parse(sessionStorage.getItem("filterSubject")));
    filterStatus = CheckNull(JSON.parse(sessionStorage.getItem("filterStatus")));
    if ((filterCountry || filterSite || filterSubject || filterStatus) && (filterCountry.length != 0 || filterSite.length != 0 || filterSubject.length != 0 || filterStatus.length != 0)) {
        $.each(filterCountry, function (i, val) {
            if (val != null)
                val = val.toLowerCase().trim()
            $("input[value='" + val + "']").prop('checked', true);
        });
        $.each(filterSite, function (i, val) {
            if (val != null)
                val = val.trim()
            $("input[value='" + val + "']").prop('checked', true);
        });
        $.each(filterSubject, function (i, val) {
            if (val != null)
                val = val.trim()
            $("input[value='" + val + "']").prop('checked', true);
        });
        $.each(filterStatus, function (i, val) {
            if (val != null)
                val = val.toLowerCase()
            $("input[value='" + val + "']").prop('checked', true);
        });
        FilterCommonDataFunction(MetricName, MetricData);
    }
}

function AddGenericfilter() {
    $("#AdvFilterModal #GenericFilter").empty();
    CreateCheckBoxDropDesign("", "StudyFilter", "CountryCommon", "#AdvFilterModal #GenericFilter", "Country")
    CreateCheckBoxDropDesign("AdvFilterHeadPadding", "SiteFilter", "SiteCommon", "#AdvFilterModal #GenericFilter", "Site")
    CreateCheckBoxDropDesign("AdvFilterHeadPadding", "SubjectFilter", "SubjectCommon", "#AdvFilterModal #GenericFilter", "Subject")
    CreateCheckBoxDropDesign("AdvFilterHeadPadding", "StatusFilter", "AdvStatusCommon", "#AdvFilterModal #GenericFilter", "Status")
}

/**CreateCountryAdvanceFilter used to add dynamic data to country dropdown**/
function CreateCountryAdvanceFilter(MetricData, indexVal) {
    if (MetricData[0].hasOwnProperty('Country'))
        CountryVar = "Country"
    else if (MetricData[0].hasOwnProperty('COUNTRY'))
        CountryVar = "COUNTRY"
    else if (MetricData[0].hasOwnProperty('Countries'))
        CountryVar = "Countries"
    else if (MetricData[0].hasOwnProperty('COUNTRY_NAME'))
        CountryVar = "COUNTRY_NAME"
    else {
        $('#StudyFilter').hide()
    }
    /*Country Filter List Creation*/
    if (CountrisList.length != 0) {
        CountrisList = [...new Set(CountrisList.concat([...new Set(MetricData.map(x => x[CountryVar]))]))];
    }
    else {
        CountrisList = [...new Set(MetricData.map(x => x[CountryVar]))];
    }

    if (indexVal == 1 && CountrisList != undefined && CountrisList.length != 0) {
        if (CountrisList.length == 1 && CountrisList[0] == undefined) {
            $('#StudyFilter').hide()
        }
        else {
            $('#StudyFilter').show()
            AddDropElement(CountrisList, "Country", "CountryName", ".CountryCommon")
        }
    }

}

/**CreateSiteAdvanceFilter used to add dynamic data to site dropdown**/
function CreateSiteAdvanceFilter(MetricData, indexVal) {
    if (MetricData[0].hasOwnProperty('Site_ID'))
        SiteVar = "Site_ID"
    else if (MetricData[0].hasOwnProperty('SITE_ID'))
        SiteVar = "SITE_ID"
    else if (MetricData[0].hasOwnProperty('Site_Id'))
        SiteVar = "Site_Id"
    else if (MetricData[0].hasOwnProperty('STUDY_SITE_IDENTIFIER'))
        SiteVar = "STUDY_SITE_IDENTIFIER"
    else if (MetricData[0].hasOwnProperty('site'))
        SiteVar = "site"
    else if (MetricData[0].hasOwnProperty('Site1'))
        SiteVar = "Site1"
    else {
        $('#SiteFilter').hide()
    }
    /*Site Filter List Creation*/
    if (SiteList.length != 0) {
        SiteList = [...new Set(SiteList.concat([...new Set(MetricData.map(x => x[SiteVar]))]))];
    }
    else {
        SiteList = [...new Set(MetricData.map(x => x[SiteVar]))];
    }


    if (indexVal == 1 && SiteList != undefined && SiteList.length != 0) {
        if (SiteList.length == 1 && SiteList[0] == undefined) {
            $('#SiteFilter').hide()
        }
        else {
            $('#SiteFilter').show()
            AddDropElement(SiteList.sort(), "Site", "SiteName", ".SiteCommon")
        }
    }
}

/**CreateSubjectAdvanceFilter used to add dynamic data to subject dropdown**/
function CreateSubjectAdvanceFilter(MetricName, MetricData, indexVal) {
    /*Subject Filter List Creation*/
    if (MetricData[0].hasOwnProperty('SUBJECT_ID'))
        SubjectVar = "SUBJECT_ID"
    else if (MetricData[0].hasOwnProperty('Subject_ID'))
        SubjectVar = "Subject_ID"
    else if (MetricData[0].hasOwnProperty('STUDY_SUBJECT_IDENTIFIER'))
        SubjectVar = "STUDY_SUBJECT_IDENTIFIER"
    else {
        $('#SubjectFilter').hide()
    }
    if (SubjectList.length != 0) {
        SubjectList = [...new Set(SubjectList.concat([...new Set(MetricData.map(x => x[SubjectVar]))]))];
    }
    else {
        SubjectList = [...new Set(MetricData.map(x => x[SubjectVar]))]
    }

    if (indexVal == 1 && SubjectList != undefined && SubjectList.length != 0) {
        if ((MetricName == "PriorityAlert") || (SubjectList.length == 1 && SubjectList[0] == undefined)) {
            $('#SubjectFilter').hide()
        }
        else {
            $('#SubjectFilter').show()
            AddDropElement(SubjectList.sort(), "Subject", "SubjectName", ".SubjectCommon")
        }
    }

}


/**CreateStatusAdvanceFilter used to add dynamic data to status dropdown**/
function CreateStatusAdvanceFilter(MetricData, indexVal) {
    /*status Filter List Creation*/
    if (MetricData[0].hasOwnProperty('Status'))
        StatusVar = "Status"
    else if (MetricData[0].hasOwnProperty('STATUS'))
        StatusVar = "STATUS"
    else if (MetricData[0].hasOwnProperty('Event_Status'))
        StatusVar = "Event_Status"
    else if (MetricData[0].hasOwnProperty('status'))
        StatusVar = "status"
    else {
        $('#StatusFilter').hide()
    }
    if (StatusList.length != 0) {
        StatusList = [...new Set(StatusList.concat([...new Set(MetricData.map(x => x[StatusVar]))]))];
    }
    else {
        StatusList = [...new Set(MetricData.map(x => x[StatusVar]))]
    }

    if (indexVal == 1 && StatusList != undefined && StatusList.length != 0) {
        if (StatusList.length == 1 && StatusList[0] == undefined) {
            $('#StatusFilter').hide()
        }
        else {
            $('#StatusFilter').show()
            AddDropElement(StatusList, "Status", "StatusName", ".AdvStatusCommon")
        }
    }

}

/**CreatePageLevelFilters used to add page level filters**/
function CreatePageLevelFilters(MetricName, MetricData) {
    if (MetricName == "Endpoints") {
        CreateEndpointFilters(MetricData)
    }
    else if (MetricName == "Medical history") {
        CreateMedicalHistoryFilters(MetricData)
    }
    else if (MetricName == "Screen Fail") {
        CreateScreenFailFilters(MetricData)
    }
    else if (MetricName == "Disposition") {
        CreateDispositionPageFilters(MetricData)
    }
    else if (MetricName == "Eligibility") {
        CreateEligibilityFilters(MetricData)
    }
    else if (MetricName == "MMCBCData") {
        CreateLabsFilters(MetricData)
    }
    else if (MetricName == "LiverFunctions") {
        CreateLiverFunctionsFilters(MetricData)
    }
    else if (MetricName == "ECG") {
        CreateECGFilters(MetricData)
    }
    else if (MetricName == "AE/SAE Count") {
        CreateAECountFilters(MetricData)
    }
    else if (MetricName == "Conmeds") {
        CreateConmedsFilters(MetricData)
    }
    else if (MetricName == "MMVitalSignsBMIData") {
        CreateBMIFilters(MetricData);
    }
    else if (MetricName == "BloodPressure") {
        CreateBloodPressureFilters(MetricData)
    }
    else if (MetricName == "Vitals") {
        CreateVitalPageFilters(MetricData)
    } 
    else if (MetricName == "Demographics") {
        CreateDemographicsPageFilters(MetricData)
    }
    else if (MetricName == "PriorityAlert") {
        CreatePriorityAlertFilters(MetricData)
    }
}


function FilterCommonDataFunction(MetricName, ...MetricData) {
    
    if (MetricName == "Endpoints") {
        EndpointStusySelect = [];
    }
    if (MetricData[0] && MetricData[0][0][0]) {
        MetricData = MetricData[0];
    }
    $('.AdvanceFilterSection').empty();
    const checkboxesCountry = document.querySelectorAll('.CountryName');
    var filterCountry = [];
    var filterNotCountry = [];
    //For Country selected Array and filteration
    checkboxesCountry.forEach((checkbox, ind) => {
        if (checkbox.checked == true) {
            filterCountry.push(checkbox.value);
        }
        else {
            filterNotCountry.push(checkbox.value);
        }
    });
    //For Site selected Array and filteration
    const checkboxesSite = document.querySelectorAll('.SiteName');
    var filterSite = [];
    var filterNotSite = [];
    checkboxesSite.forEach((checkbox, ind) => {
        if (checkbox.checked == true) {
            filterSite.push(checkbox.value);
        }
        else {
            filterNotSite.push(checkbox.value);
        }
    });

    //For Subject selected Array and filteration
    const checkboxesSubject = document.querySelectorAll('.SubjectName');
    var filterSubject = [];
    var filterNotSubject = [];
    checkboxesSubject.forEach((checkbox, ind) => {
        if (checkbox.checked == true) {
            filterSubject.push(checkbox.value);
        }
        else {
            filterNotSubject.push(checkbox.value);
        }
    });
    //For Status selected Array and filteration
    const checkboxesStatus = document.querySelectorAll('.StatusName');
    var filterStatus = [];
    var filterNotStatus = [];
    checkboxesStatus.forEach((checkbox, ind) => {
        if (checkbox.checked == true) {
            filterStatus.push(checkbox.value);
        }
        else {
            filterNotStatus.push(checkbox.value);
        }
    });
    filterCountryses = CheckNull(JSON.parse(sessionStorage.getItem("filterCountry")));
    filterSiteSes = CheckNull(JSON.parse(sessionStorage.getItem("filterSite")));
    filterSubjectSes = CheckNull(JSON.parse(sessionStorage.getItem("filterSubject")));
    filterStatusSes = CheckNull(JSON.parse(sessionStorage.getItem("filterStatus")));
    if ((filterCountryses) && (filterCountryses.length != 0)) {
        filterCountryses.forEach(function (check) {
            if (filterCountry.indexOf(check) < 0 && filterNotCountry.indexOf(check) < 0) {
                filterCountry.push(check)
            }
        })
    }
    if (filterSiteSes && filterSiteSes.length != 0) {
        filterSiteSes.forEach(function (check) {
            if (filterSite.indexOf(check) < 0 && filterNotSite.indexOf(check) < 0) {
                filterSite.push(check)
            }
        })
    }
    if (filterSubjectSes && filterSubjectSes.length != 0) {
        filterSubjectSes.forEach(function (check) {
            if (filterSubject.indexOf(check) < 0 && filterNotSubject.indexOf(check) < 0) {
                filterSubject.push(check)
            }
        })
    }
    if (filterStatusSes && filterStatusSes.length != 0) {
        filterStatusSes.forEach(function (check) {
            if (filterStatus.indexOf(check) < 0 && filterNotStatus.indexOf(check) < 0) {
                filterStatus.push(check)
            }
        })
    }
    window.sessionStorage.setItem("filterCountry", JSON.stringify(filterCountry));
    window.sessionStorage.setItem("filterSite", JSON.stringify(filterSite));
    window.sessionStorage.setItem("filterSubject", JSON.stringify(filterSubject));
    window.sessionStorage.setItem("filterStatus", JSON.stringify(filterStatus));
    if ((filterCountry || filterSite || filterSubject || filterStatus) && (filterCountry.length != 0 || filterSite.length != 0 || filterSubject.length != 0 || filterStatus.length != 0)) {
        MetricData.forEach(function (DtElement, i) {
            if (DtElement) {
                MetricData[i] = FilterCountrySiteSubjectStatus(MetricData[i])
            }
        })
        if (filterCountry && filterCountry.length != 0 && $("#StudyFilter").css("display") != 'none') {
            AddFilterTag(".AdvanceFilterSection", "Country", ".CountryName")
        }
        if (filterSite && filterSite.length != 0 && $("#SiteFilter").css("display") != 'none') {
            AddFilterTag(".AdvanceFilterSection", "Site", ".SiteName")
        }
        if (filterSubject && filterSubject.length != 0 && $("#SubjectFilter").css("display") != 'none') {
            AddFilterTag(".AdvanceFilterSection", "Subject", ".SubjectName")
        }
        if (filterStatus && filterStatus.length != 0 && $("#StatusFilter").css("display") != 'none') {
            AddFilterTag(".AdvanceFilterSection", "Status", ".StatusName")
        }
    }
    FiterAdvObj1 = MetricData[0];
    dc.deregisterAllCharts();
    if (MetricName == "Endpoints") {
        FilterEndPointPageDataFunction(MetricData)
    }
    else if (MetricName == "Medical history") {
        FilterMedHistoryPageDataFunction(MetricData)
    }
    else if (MetricName == "Screen Fail") {
        FilterScreenFailPageDataFunction(MetricData)
    }
    else if (MetricName == "Disposition") {
        FilterDispositionDataFunction(MetricData)
    }
    else if (MetricName == "Eligibility") {
        FilterEligibilityPageDataFunction(MetricData)
    }
    else if (MetricName == "ECG") {
        FilterECGPageDataFunction(MetricData)
    }
    else if (MetricName == "MMCBCData") {
        FilterLabsPageDataFunction(MetricData)
    }
    else if (MetricName == "LiverFunctions") {
        FilterLiverFunctionsPageDataFunction(MetricData)
    }
    else if (MetricName == "AE/SAE Count") {
        FilterAECountPageDataFunction(MetricData)
    }
    else if (MetricName == "AE Rates Per Subject Week") {
        FilterAEPerWeekPageDataFunction(MetricData)
    }
    else if (MetricName == "Conmeds") {
        FilterConmedsPageDataFunction(MetricData)
    }
    else if (MetricName == "Vitals") {
        FilterVitalsPageDataFunction(MetricData)
    }
    else if (MetricName == "IP Exposure") {
        FilterIPExposurePageDataFunction(MetricData)
    }
    else if (MetricName == "BloodPressure") {
        FilterBloodPressuePageDataFunction(MetricData)
    }
    else if (MetricName == "Demographics") {
        FilterDemographicsDataFunction(MetricData)
    }
    else if (MetricName == "MMVitalSignsBMIData") {
        FilterBMIPageDataFunction(MetricData)
    }
    else if (MetricName == "PriorityAlert") {
        FilterPriorityAlertDataFunction(MetricData)
    }
}

/*To filter data for selected country,site ,status and subject*/
function FilterCountrySiteSubjectStatus(data) {
    filterCountry = CheckNull(JSON.parse(sessionStorage.getItem("filterCountry")));
    filterSite = CheckNull(JSON.parse(sessionStorage.getItem("filterSite")));
    filterSubject = CheckNull(JSON.parse(sessionStorage.getItem("filterSubject")));
    filterStatus = CheckNull(JSON.parse(sessionStorage.getItem("filterStatus")));
    var filterData = data;
    if (filterCountry && filterCountry.length != 0 && $("#StudyFilter").css("display") != 'none' && data[0] && data[0].hasOwnProperty(CountryVar)) {
        filterData = FilterSelectedData(filterData, filterCountry, CountryVar)
    }
    if (filterSite && filterSite.length != 0 && $("#SiteFilter").css("display") != 'none' && data[0] && data[0].hasOwnProperty(SiteVar)) {
        filterData = FilterSelectedData(filterData, filterSite, SiteVar)
    }
    if (filterSubject && filterSubject.length != 0 && $("#SubjectFilter").css("display") != 'none' && data[0] && data[0].hasOwnProperty(SubjectVar)) {
        filterData = FilterSelectedData(filterData, filterSubject, SubjectVar)
    }
    if (filterStatus && filterStatus.length != 0 && $("#StatusFilter").css("display") != 'none' && data[0] && data[0].hasOwnProperty(StatusVar)) {
        filterData = FilterSelectedData(filterData, filterStatus, StatusVar)
    }
    return filterData;
}

function CheckNull(dataString) {
    if (dataString != null && dataString != undefined) {
        dataString.filter(function (el) {
            return el != null;
        });
    }
    return dataString;
}
$(".FilterReset").click(function () {
    $("#ResetAll").css("display", "none")
    FiterAdvObj1 = [];
    resetAllFilter();
    $('#FilterScreenDisplay .sidenav-close').css('pointer-events', 'none').css('opacity', 0.2);
    if (show) {
        show = false;
    }
    dc.deregisterAllCharts();
    ChartRecreation()
})
function resetAllFilter() {
    sessionStorage.removeItem('filterCountry');
    sessionStorage.removeItem('filterSite');
    sessionStorage.removeItem('filterSubject');
    sessionStorage.removeItem('filterStatus');
    sessionStorage.removeItem('FilterData');
    $(".AdvCheckBoxCls").prop("checked", false);
    $(".AdvRadioCls").prop("checked", false);
    $('.AdvanceFilterSection').empty();
    selectedInputFieldsDone = [];
    AdvanceFilterApplied = false;
}
function showHideReset(FilterCondition) {
    if (FilterCondition) {
        $('#ResetAll').css('visibility', 'visible');
        $('#ResetAll').css('opacity', 1);
    }
    else {
        // $('#ResetAll').css('visibility', 'hidden');
        $('#ResetAll').css('opacity', 0.5);
    }
}

function showCheckboxesCommon(classNamedrp) {
    $(".DrpContain:not(." + classNamedrp + ")").removeClass("show")
    $("." + classNamedrp).toggleClass("show")
}

/**Common filter function to filter selected data */
function FilterSelectedData(FilterObject, SelectedData, FilterBasedOn) {
    FilterObject = FilterObject.filter((el) => {
        return SelectedData.some((f) => {
            if (el[FilterBasedOn] && el[FilterBasedOn] != null && f != null && isNaN(el[FilterBasedOn])) {
                return f.toLowerCase().trim() == el[FilterBasedOn].toLowerCase().trim();
            }
            else {
                return f == el[FilterBasedOn];
            }
        });
    });
    filterApplied = true;
    debugger;
    return FilterObject;
}

/**Common filter function to filter selected date range */
function FilterSelectedDateRange(FilterObject, StartDate, EndDate, FilterBasedOn) {
    debugger;
    FilterObject = FilterObject.filter((el) => {
        return StartDate <= el[FilterBasedOn] && EndDate >= el[FilterBasedOn];
    });
    filterApplied = true;
    return FilterObject;
}

/**To add layout for drop dwon in filter */
function CreateCheckBoxDropDesign(MainDivClass, MainDivId, DrpDownClass, appendTo, DivHeading) {
    $(appendTo).append(`<div id="` + MainDivId + `" class="` + MainDivClass + `">
        <p class="ModalDrpTitle" > ` + DivHeading + `</p ><div class="DrpHeader" onclick="showCheckboxesCommon('` + DrpDownClass + `')"><p>Select</p> <img src="../MMCoreAssets/icons/Icon_MM_Persona/Icon_MM_Persona/arrow_drop_down.svg" /></div><div class="` + DrpDownClass + ` DrpContain"></div> </div > `)
}

/**To add layout for date range in filter */
function CreateDateRangeDesign(MainDivClass, MainDivId, appendTo, DivHeading) {
    $(appendTo).append(`<div id="` + MainDivId + `" class="` + MainDivClass + `">
        <p class="ModalDrpTitle" > ` + DivHeading + `</p >
        <div>
            <label id="startdate" style="float: left">To</label>
            <label id="enddate" style="margin-left: 22%;">From</label>
            <input type="date" placeholder="Start Date" onkeydown="return false" id="EndDateCalender" name="return_date" class="FilterDateRange">
            <input type="date" placeholder="End Date" onkeydown="return false" id="StartDateCalender" name="return_date" class="FilterDateRange" style="margin-left: 11%;">
        </div>
        </div > `)
}

/**To add layout for range slider in filter */
function CreateRangeSliderDesign(MainDivClass, MainDivId, appendTo, DivHeading) {
    debugger;
    $(appendTo).append(`<div id="` + MainDivId + `" class="` + MainDivClass + `">
        <p class="ModalDrpTitle" > ` + DivHeading + `</p >
        <div>
            <div class="filter-container">
                <div class="filter-section">
                    <div class="slider-wrapper">
                        <div id="slider" class="store-slider"></div>
                    </div>
                    <div class="row filter-row">
                        <div class="col s6 mb9 pr26">
                            <div class="input-group">
                                <input type="text" id="range_from">
                            </div>
                        </div>
                        <div class="col s6 mb9 pr26">
                            <div class="input-group">
                                <input type="text" id="range_to">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div > `)
}

/**To add checkbox element to filter drop down */
function AddDropElement(DropDownData, DrpDownEleId, DrpDownEleClass, appendTo) {
    DropDownData.forEach((data, ind) => {
        if (data != null) {
            var dropVal = data;
            if (isNaN(dropVal)) {
                dropVal = dropVal.toLowerCase().trim()
            }
            $(appendTo).append(`<label for="` + DrpDownEleId + ind + `">
                    <input type="checkbox" id="` + DrpDownEleId + ind + `" class="` + DrpDownEleClass + ` AdvCheckBoxCls" value="` + dropVal + `" />
                    <span>`+ data + `</span></label>`)
        }
    });
}

/**To add layout for List in filter */
function CreateListDesign(MainDivClass, MainDivId, DrpDownClass, DrpDownId, appendTo, DivHeading) {
    $(appendTo).append(`<div id="` + MainDivId + `" class="` + MainDivClass + `">
            <p class="ModalDrpTitle"> ` + DivHeading + `</p>
            <div id="`+ DrpDownId + `"  class="` + DrpDownClass + `"></div></div>`)
}

/**To add layout for radio button list in filter */
function CreateRadioListDesign(MainDivClass, MainDivId, DrpDownClass, DrpDownId, appendTo, DivHeading) {
    $(appendTo).append(`<div id="` + MainDivId + `" class="` + MainDivClass + `">
            <p class="ModalDrpTitle"> ` + DivHeading + `</p>
            <div id="`+ DrpDownId + `"  class="` + DrpDownClass + `"></div></div>`)
}

/**To add radio button element to filter list */
function AddRadioDropElement(DropDownData, DrpDownEleId, DrpDownEleClass, appendTo) {
    DropDownData.forEach((data, ind) => {
        if (data != null) {
            var dropVal = data;
            if (isNaN(dropVal)) {
                dropVal = dropVal.trim()
            }
            $(appendTo).append(`<label for="` + DrpDownEleId + ind + `">
                    <input type="radio" id="` + DrpDownEleId + ind + `" class="` + DrpDownEleClass + ` AdvRadioCls" value="` + dropVal + `" name="` + DrpDownEleClass + `" />
                    <span>`+ data + `</span></label>`)
        }
    });
    
}
function AddFilterTag(appendTo, Tagvalue, SectionClass) {
    var tagCls;
    var CompleteTagValue = Tagvalue;
    if (Tagvalue != null && Tagvalue.length > 16) {
        Tagvalue = Tagvalue.substring(0, 16) + "..."
    }
    if (!$('.FilterSelection').html()) {
        $(appendTo).append(`<div class="FilterSelection" id="clearFilter" onclick="ClearAdvfilter()"><span>CLEAR ALL </span><a class="FilterRemovala" href="#!"><img class="FilterRemoval" src="../MMCoreAssets/Images/Close.svg" /></a></div>`)
    }
    if (Tagvalue.includes(" ")) {
        tagCls = Tagvalue.substring(0, Tagvalue.indexOf(' '))
        if ($("." + tagCls + "Filter").html()) {
            tagCls = tagCls + "1";
        }
    }
    else {
        tagCls = Tagvalue
    }
    if (SelectedDataClass.indexOf(SectionClass) == -1) {
        SelectedDataClass.push(SectionClass);
    }
    var RemoveFilterparameter = JSON.stringify([SectionClass, tagCls])
    if (CompleteTagValue != Tagvalue) {
        $(appendTo).append(`<div class="FilterSelection FilterSelectionCommon ` + tagCls + `FilterCls"><span  style="color: #242424;font: normal normal 600 12px/16px Open Sans;" class="tooltipped" data-toggle="tooltip" data-placement="bottom" data-tooltip="` + CompleteTagValue + `">` + Tagvalue + `</span><a class="FilterRemovala" href="#!" onclick='RemoveFilter(` + RemoveFilterparameter + `)'><img class="FilterRemoval" src="../MMCoreAssets/Images/Close.svg" /></a></div>`)
        $('.tooltipped').tooltip();
    }
    else {
        $(appendTo).append(`<div class="FilterSelection FilterSelectionCommon ` + tagCls + `FilterCls"><span>` + Tagvalue + `</span><a class="FilterRemovala" href="#!" onclick='RemoveFilter(` + RemoveFilterparameter + `)'><img class="FilterRemoval" src="../MMCoreAssets/Images/Close.svg" /></a></div>`)
    }
}
function RemoveFilter(RemoveFilterparameter) {
    if (SelectedDataClass.indexOf(RemoveFilterparameter[0]) >= 0) {
        var indx = SelectedDataClass.indexOf(RemoveFilterparameter[0]);
        SelectedDataClass.splice(indx, 1);
    }
    $("." + RemoveFilterparameter[1] + "FilterCls").remove();
    if (RemoveFilterparameter[0] == '.CountryName') {
        sessionStorage.removeItem('filterCountry');
    }
    else if (RemoveFilterparameter[0] == '.SiteName') {
        sessionStorage.removeItem('filterSite');
    }
    else if (RemoveFilterparameter[0] == '.SubjectName') {
        sessionStorage.removeItem('filterSubject');
    }
    else if (RemoveFilterparameter[0] == '.StatusName') {
        sessionStorage.removeItem('filterStatus');
    }
    $(RemoveFilterparameter[0]).prop("checked", false);
    if (!$('.FilterSelectionCommon').html()) {
        ClearAdvfilter();
    }
    else {
        CommonFilterData();
    }
}
$("#AdvFilterModal #RoleDone").click(function () {
    var selecteddata = $("#AdvFilterModal input:checked");
    for (var i = 0; i < selecteddata.length; i++) {
        var d = ((selecteddata[i].className).split(" "));
        selectedInputFieldsDone[i] = { 'id': selecteddata[i].id, 'classNames': [d[0], d[1]]}
    }
    window.sessionStorage.setItem("FilterData", JSON.stringify(selectedInputFieldsDone));
});
$("#AdvFilterModal .modal-close").click(function () {
    if (sessionStorage.getItem("selectedInputFieldsDone")) {
        selectedInputFieldsDone = JSON.parse(sessionStorage.getItem("FilterData"))
    }
    $(".DrpContain").removeClass("show");
    var Addcheckclas = [];
    var AddRadioCls = [];
    var AllClss = [];
    Addcheckclas = $(".AdvCheckBoxCls");
    AddRadioCls = $(".AdvRadioCls");
    for (var i = 0; i < Addcheckclas.length; i++) {
        var d = ((Addcheckclas[i].className).split(" "));
        AllClss.push({ 'id': Addcheckclas[i].id, 'classNames': [d[0], d[1]] });
    }
    for (var i = 0; i < AddRadioCls.length; i++) {
        var d = ((AddRadioCls[i].className).split(" "));
        AllClss.push({ 'id': AddRadioCls[i].id, 'classNames': [d[0], d[1]] });
    }
    AllClss.forEach((data, ind) => {
        const index = selectedInputFieldsDone.findIndex(object => {
                return object.id == data.id;
            });
        if (index < 0) {
            var a = "#" + data.id;
         $(a).prop("checked", false);
        }
        if (index >= 0) {
            var a = "#" + data.id;
            $(a).prop("checked", true);
        }
    });   
});
function ClearAdvfilter() {
    debugger
    $(".FilterReset").trigger('click');
}