﻿//****Start: Range Slider in Filter****
console.clear();

var currentValue = {
    from: 50,  //1106,
    to: 100  //10000
}

var slider = $('#slider').slider({
    range: true,
    min: 0,
    max: 500,  //11850,
    values: [currentValue.from, currentValue.to],
    create: function (event, ui) {
        var $slider = $(this);
        var $sliderWrapper = $slider.closest('.store-slider-wrapper');
        var $sliderHandlers = $slider.find('.ui-slider-handle');
        var $sliderHandlersMin = $sliderHandlers.eq(0);
        var $sliderHandlersMax = $sliderHandlers.eq(1);
        var $sliderRange = $slider.find('.ui-slider-range');
        var values = {
            from: currentValue.from,
            to: currentValue.to
        }

        $sliderHandlersMin.attr('title', values.from);
        $sliderHandlersMax.attr('title', values.to);
        $sliderRange
            .attr('title', values.from + ' - ' + values.to)
            .attr('data-tippy-distance', 15);;

        var tippyOptions = {
            trigger: 'manual',
            sticky: true,
            dynamicTitle: true,
            hideOnClick: false,
            arrow: true,
            arrowType: 'round',
            animation: 'fade',
            placement: 'top',
            livePlacement: false,
            flipBehavior: [],
            createPopperInstanceOnInit: true,
            appendTo: $(this).closest('.filter-section')[0],
            popperOptions: {
                modifiers: {
                    // preventOverflow: {
                    //     boundariesElement: $(this).closest('.filter-section')[0],
                    // }
                    computeStyle: {
                        gpuAcceleration: true
                    }
                },
            }
        };

        
        tippy($sliderHandlersMin[0], tippyOptions);
        tippy($sliderHandlersMax[0], tippyOptions);
        tippy($sliderRange[0], tippyOptions);
        
        updateSliderTooltip($slider, values);
    },
    slide: function (event, ui) {
        var $slider = $(this);
        var $sliderWrapper = $slider.closest('.store-slider-wrapper');
        var values = {
            from: ui.values[0],
            to: ui.values[1]
        }

        updateSliderTooltip($slider, values, true);
    }
});

function updateSliderTooltip($slider, values, updateInput) {
    if (typeof updateInput === "undefined")
        var updateInput = true;

    var $sliderWrapper = $slider.closest('.store-slider-wrapper');
    var $sliderHandlers = $slider.find('.ui-slider-handle');
    var $sliderHandlersMin = $sliderHandlers.eq(0);
    var $sliderHandlersMax = $sliderHandlers.eq(1);
    var $sliderRange = $slider.find('.ui-slider-range');

    $sliderHandlersMin.attr('title', values.from);
    $sliderHandlersMax.attr('title', values.to);
    $sliderRange.attr('title', values.from + ' ' + values.to);

    if (updateInput) {
        $('#range_from').val(values.from);
        $('#range_to').val(values.to);
    }

    setInterval(function () {
        var tooltipMinLeft = getCoords($sliderHandlersMin[0]).left;
        var tooltipMaxLeft = getCoords($sliderHandlersMax[0]).left;

        var tooltipRange = tooltipMaxLeft - tooltipMinLeft;
        var singleTooltip = tooltipRange < 80;

        if (!singleTooltip) {
            if (!$sliderHandlersMin[0]._tippy.state.visible)
                $sliderHandlersMin[0]._tippy.show(0);
            if (!$sliderHandlersMax[0]._tippy.state.visible)
                $sliderHandlersMax[0]._tippy.show(0);
            if ($sliderRange[0]._tippy.state.visible)
                $sliderRange[0]._tippy.hide(0);
        } else {
            if ($sliderHandlersMin[0]._tippy.state.visible)
                $sliderHandlersMin[0]._tippy.hide(0);
            if ($sliderHandlersMax[0]._tippy.state.visible)
                $sliderHandlersMax[0]._tippy.hide(0);
            if (!$sliderRange[0]._tippy.state.visible)
                $sliderRange[0]._tippy.show(0);
        }
    }, 1);
}

function updateValues() {
    var from = $('#range_from').val();
    var to = $('#range_to').val();

    updateSliderTooltip(slider, {
        from: from,
        to: to
    }, false);

    slider.slider({
        values: [from, to]
    });
}

$('#range_from').on('blur', function () {
    $(this).val($(this).val().replace(/[^0-9]/i, ''));

    if (+$(this).val() > +$('#range_to').val()) {
        $(this).val($('#range_to').val())
    }

    updateValues();
});

$('#range_to').on('blur', function () {
    $(this).val($(this).val().replace(/[^0-9]/gi, ''));

    if (+$(this).val() < +$('#range_from').val()) {
        $(this).val($('#range_from').val())
    }

    updateValues();
});

function getCoords(elem) {
    var box = elem.getBoundingClientRect();

    var body = document.body;
    var docEl = document.documentElement;

    var scrollTop = window.pageYOffset || docEl.scrollTop || body.scrollTop;
    var scrollLeft = window.pageXOffset || docEl.scrollLeft || body.scrollLeft;

    var clientTop = docEl.clientTop || body.clientTop || 0;
    var clientLeft = docEl.clientLeft || body.clientLeft || 0;

    var top = box.top + scrollTop - clientTop;
    var left = box.left + scrollLeft - clientLeft;

    return { top: Math.round(top), left: Math.round(left) };
}
//****End: Range Slider in Filter****